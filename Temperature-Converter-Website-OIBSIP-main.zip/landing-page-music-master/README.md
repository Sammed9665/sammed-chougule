<h1 align="center">uMusic</h1>
<p align="center">✒️ Design study for music library responsive using html and css</p>
<p align="center">
  <a href="http://umusic.surge.sh/">Check deploy</a>
</p>

<p align="center">
  <img src="./assets/desktop.gif" width="1000">
</p>
<p align="center">
  <img src="./assets/mobile.gif" width="200">
</p>

